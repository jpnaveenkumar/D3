Steps To Run the Source code : 

Start the http server inside the project directory.

http-server --cors --port 9999

Open index.html file inside the directory in the browser.
